

# Verify cnn_accel.ko is loaded and /dev/cnn0 is created.

xilinx-kv260-starterkit-20251:~/Lenet_App$ ls /dev/cnn0 
/dev/cnn0

xilinx-kv260-starterkit-20251:~/Lenet_App$ lsmod
Module                  Size  Used by
cfg80211              385024  0
cnn_accel              12288  0
mali                  225280  0


# Load the FPGA bitstream: -
sudo fpgautil -b system.bit.bin


# Run the application: -
sudo ./main_ioctlapp
