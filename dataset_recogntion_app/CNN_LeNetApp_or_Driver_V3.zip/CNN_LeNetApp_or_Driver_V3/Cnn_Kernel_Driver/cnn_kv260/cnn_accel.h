// SPDX-License-Identifier: GPL-2.0 */
/*
 * cnn_accel.h - Kernel-internal header for CNN accelerator driver
 */
#ifndef CNN_ACCEL_H
#define CNN_ACCEL_H

#include "cnn_accel_uapi.h"

#endif /* CNN_ACCEL_H */
