// SPDX-License-Identifier: GPL-2.0 */
#ifndef TEST_IMAGES_H
#define TEST_IMAGES_H

#include <stdint.h>

#define NUM_TEST_IMAGES         10000
#define PIXELS_PER_IMAGE        784

extern const uint8_t test_labels[NUM_TEST_IMAGES];
extern const int32_t test_images_fixed[NUM_TEST_IMAGES][PIXELS_PER_IMAGE];

#endif /* TEST_IMAGES_H */
