
## Prepare cross compile environment: -
source /opt/Petalinux_Cross_Compiler/environment-setup-cortexa72-cortexa53-amd-linux
 
echo $CC

## Compilation: - 

$CC cnn_test.c weights_array.c test_images.c -o main_VGGioctlapp


Note:  If above source command gives error ".....you probably need to 'unset LD_LIBRARY_PATH'....", then run
below command: -

unset LD_LIBRARY_PATH


## Running the application: -
sudo fpgautil -b design_1_wrapper.bit.bin
sudo ./main_VGGioctlapp
