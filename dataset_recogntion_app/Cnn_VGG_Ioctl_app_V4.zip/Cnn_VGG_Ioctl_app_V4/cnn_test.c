// SPDX-License-Identifier: GPL-2.0
/*
 * cnn_test.c - Userspace test for CNN accelerator kernel driver
 *
 * Build:
 *   gcc -o cnn_test cnn_test.c -I. -lm
 *
 * Run:
 *   sudo ./cnn_test
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdint.h>

#include "cnn_accel_uapi.h"
#include "weights_array.h"
#include "test_images.h"

#define DEV_PATH            "/dev/cnn0"

static int load_weights(int fd)
{
    struct cnn_weight_data wd;
    int ret;

    wd.count = NUM_WEIGHTS;
    wd.data  = (uint32_t *)weights_fixed;   /* point directly at the const array */

    ret = ioctl(fd, CNN_IOCTL_LOAD_WEIGHTS, &wd);
    if (ret < 0) {
        perror("ioctl LOAD_WEIGHTS");
        return -1;
    }

    return 0;
}

static int run_inference(int fd, const int32_t *image)
{
    struct cnn_inference_req req;

    req.input_size = CNN_INPUT_SIZE;
    memcpy(req.image, image, CNN_INPUT_SIZE * sizeof(uint32_t));

    if (ioctl(fd, CNN_IOCTL_RUN_INFERENCE, &req) < 0) {
        perror("ioctl RUN_INFERENCE");
        return -1;
    }

    return req.result;
}

int main(void)
{
    int fd, correct = 0, i;

    fd = open(DEV_PATH, O_RDWR);
    if (fd < 0) {
        perror("open " DEV_PATH);
        return 1;
    }

    printf("\n==================================================\n");
    printf("  CNN MNIST Inference (kernel driver)\n");
    printf("==================================================\n\n");

    printf("Loading weights...\n");
    if (load_weights(fd)) {
        close(fd);
        return 1;
    }
    printf("Weights loaded.\n");

    printf("Running inference on %d test images...\n\n", NUM_TEST_IMAGES);

    for (i = 0; i < NUM_TEST_IMAGES; i++) {
        int predicted = run_inference(fd, test_images_fixed[i]);
        int expected = test_labels[i];

        if (predicted < 0) {
            printf("Image %d: ERROR\n", i);
            continue;
        }

        printf("Image %d: ", i);
        if (predicted == expected) {
            printf("PASS - Predicted: %d, Expected: %d\n",
                   predicted, expected);
            correct++;
        } else {
            printf("FAIL - Predicted: %d, Expected: %d\n",
                   predicted, expected);
        }
    }

    printf("\n==================================================\n");
    printf("  RESULTS\n");
    printf("==================================================\n");
    printf("Total images: %d\n", NUM_TEST_IMAGES);
    printf("Correct:      %d\n", correct);
    printf("Accuracy:     %.1f%%\n",
           (float)correct / NUM_TEST_IMAGES * 100.0f);
    printf("==================================================\n\n");

    if (correct == NUM_TEST_IMAGES)
        printf("ALL TESTS PASSED!\n");
    else
        printf("Some tests failed.\n");

    close(fd);
    return 0;
}
