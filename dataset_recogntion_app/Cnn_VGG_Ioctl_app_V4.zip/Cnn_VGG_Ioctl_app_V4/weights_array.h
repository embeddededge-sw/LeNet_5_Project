// SPDX-License-Identifier: GPL-2.0 */
#ifndef WEIGHTS_ARRAY_H
#define WEIGHTS_ARRAY_H

#include <stdint.h>

#define NUM_WEIGHTS             4710

extern const int32_t weights_fixed[NUM_WEIGHTS];

#endif /* WEIGHTS_ARRAY_H */
